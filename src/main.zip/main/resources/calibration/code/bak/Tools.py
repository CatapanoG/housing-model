# -*- coding: utf-8 -*-
"""
Created on Thu Apr 16 16:32:30 2015

@author: 326052
"""

myVar = 3.456 

def testfunc():
    return(2.66)    