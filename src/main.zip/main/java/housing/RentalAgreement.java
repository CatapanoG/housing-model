package housing;

public class RentalAgreement extends PaymentAgreement {
}
