package collectors;

public class CollectorBase {

	private boolean active = false;

	public boolean isActive() { return active; }

	public void setActive(boolean active) { this.active = active; }
	
	
}
